# Projeto da disciplina PCS3746 (Sistemas Operacionais) - 2023

-   Luiz Guilherme Budeu, N° USP: 11821639
-   Fernando Falquetto Coelho, Nº USP: 11820260
-   Lucas Lopes de Paula Junior, Nº USP: 9344880

# Changelog:

-   Criação do mapa de bits
-   Criação de processos
-   Alocação e desalocação da memória
-   Simulação de processo
-   Escalonamento sequencial de processos
-   Escalonamento preemptivo de processos
-   Funções de display do status, TCB, mapa de bits e fila de processos prontos
-   Prompt para o usuário salvando os comandos para comandos.txt
-   Create command
-   Kill command
-   Comandos entrando na fila
-   ~~BUGFIX: se a fila fica vazia depois de um kill, o create não funciona mais~~ resolvido
-   Configurações por config.txt
-   Compactação da memória
-   Relatorio txt
-   Terminado
